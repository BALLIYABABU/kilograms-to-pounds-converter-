# ⚖️ Kilograms to Pounds Converter (Java Swing)

A simple Java Swing application that converts kilograms to pounds **in real time** as you type.

## 🚀 Features
- Real-time conversion
- Lightweight GUI using Swing
- Error handling for invalid inputs

## 🛠️ How to Run
1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/kg-to-pounds-converter.git
   ```
2. Navigate to the folder:
   ```bash
   cd kg-to-pounds-converter
   ```
3. Compile and run:
   ```bash
   javac src/Converter.java
   java src.Converter
   ```

## 📏 Formula
```
1 kilogram = 2.20462 pounds
```

## 📸 Demo
(Add screenshot or GIF after testing)
