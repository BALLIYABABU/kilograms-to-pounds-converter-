package src;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Converter extends JFrame {

    private JTextField kgField;
    private JLabel resultLabel;

    public Converter() {
        setTitle("Kilograms to Pounds Converter");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(3, 1));

        JLabel promptLabel = new JLabel("Enter weight in kilograms:", SwingConstants.CENTER);
        kgField = new JTextField();
        resultLabel = new JLabel("Equivalent in pounds: 0.00", SwingConstants.CENTER);

        kgField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                convertAndDisplay();
            }
        });

        add(promptLabel);
        add(kgField);
        add(resultLabel);

        setVisible(true);
    }

    private void convertAndDisplay() {
        try {
            double kg = Double.parseDouble(kgField.getText());
            double pounds = kg * 2.20462;
            resultLabel.setText(String.format("Equivalent in pounds: %.2f", pounds));
        } catch (NumberFormatException ex) {
            resultLabel.setText("Please enter a valid number.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Converter::new);
    }
}
